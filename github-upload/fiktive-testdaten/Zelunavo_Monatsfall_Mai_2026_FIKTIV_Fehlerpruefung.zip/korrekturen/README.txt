Fuenf korrigierte fiktive PDF-Belege fuer die manuelle Ergaenzung nach dem Fehlerprueflauf.
Nicht Teil der Rechnungsdateien im Testlauf.
